package J04002;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double width = sc.nextFloat();
        double height= sc.nextFloat();
        String color= sc.next();
        if(width >0 && height>0 && (int) width == width &&(int) height == height)
        {
            Rectange r = new Rectange(width, height, color);
            System.out.println((int)r.findPerimeter()+" "+(int)r.findArea()+" "+r.getColor().substring(0, 1).toUpperCase()+r.getColor().substring(1));
        }
        else {
            System.out.println("INVALID");
        }
        sc.close();
    }
}
